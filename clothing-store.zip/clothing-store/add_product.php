<?php
// Include the database connection file
include('conn.php');
session_start();
if ($_SESSION['admin_username']== "") {
    header('location:login.php');
}


$message = '';

// Insert new product into the database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_code = $_POST['item_code'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $size = $_POST['size'];
    $price = $_POST['price'];
    $cost = $_POST['cost'];



    // JavaScript validation for empty fields
    echo "<script>
        function validateForm() {
            var item_code = document.getElementById('item_code').value;
            var name = document.getElementById('name').value;
            var description = document.getElementById('description').value;
            var size = document.getElementById('size').value;
            var price = document.getElementById('price').value;

            if (item_code === '' || name === '' || description === '' || size === '' || price === '') {
                alert('All fields are required.');
                return false;
            }

            return true;
        }
    </script>";

    // Check if all fields are filled
    if ($item_code !== '' && $name !== '' && $description !== '' && $size !== '' && $price !== '') {
      
$sql = "INSERT INTO products (item_code, name, description, size, price, cost) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssdd", $item_code, $name, $description, $size, $price, $cost);
        if ($stmt->execute()) {
            $message = "Product added successfully!";
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
         display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            margin-left:20%;
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 500px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .message {
            color: green;
            text-align: center;
            margin-bottom: 15px;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body><?php @include 'nv.php'; ?>

<div class="container">
    <h2>Add Product</h2>
    <?php if ($message != ''): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>
    <form action="add_product.php" method="post" onsubmit="return validateForm()">
        <div class="form-group">
            <label for="item_code">Item Code:</label>
            <input type="text" id="item_code" name="item_code" required>
        </div>

        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>

        <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea>
        </div>

        <div class="form-group">
            <label for="size">Size:</label>
            <select id="size" name="size" required>
                <option value="">Select Size</option>
                <option value="XS">XS</option>
                <option value="S">S</option>
                <option value="M">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
            </select>
        </div>
        <div class="form-group">
    <label for="cost">Cost:</label>
    <input type="text" id="cost" name="cost" required>
</div>


        <div class="form-group">
            <label for="price">Sale_Price:</label>
            <input type="text" id="price" name="price" required>
        </div>

        <button type="submit">Add Product</button>
    </form>
</div>

<div class="container">
    <h2>Product List</h2>
    <?php
    // Fetch products from the database
    $sql = "SELECT * FROM products";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
                <thead>
                    <tr>
                        <th>Item Code</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Size</th>
                        <th>Price</th>
                        <th>Action</th> <!-- Add new column for the delete button -->
                    </tr>
                </thead>
                <tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['item_code']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['description']}</td>
                    <td>{$row['size']}</td>
                    <td>{$row['price']}</td>
                    <td><form action='delete_product.php' method='post'><input type='hidden' name='id' value='{$row['id']}'><button type='submit'>Delete</button></form></td> <!-- Delete button -->
                </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p>No products found.</p>";
    }
    ?>
</div>

</body>
</html>
