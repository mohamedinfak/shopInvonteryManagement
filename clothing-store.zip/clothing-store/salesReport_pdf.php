<?php
// Include the FPDF library
include('conn.php');
session_start();
if ($_SESSION['admin_username'] == "") {
    header('location:login.php');
}
require('pdf/fpdf.php');

// Create PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'I', 12);

$date = date('Y-m-d');
$s_Date=$_SESSION['start_date'];
$e_Date=$_SESSION['end_date'];

$pdf->Cell(180, 20,"Report-Generated-Date:",0,1,'R');
$pdf->Cell(180, 5,$date, 0,1,'R');
$pdf->SetFont('Arial', 'B', 16);

$pdf->Cell(0, 10, 'Master-Shop-Sales-Details', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, $s_Date. ' " "- To - " "'.$e_Date, 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', 'I', 12);
$pdf->Cell(35, 10, 'Date', 1, 0, 'C');
$pdf->Cell(35, 10, 'Product-Name', 1, 0, 'C');
$pdf->Cell(35, 10, 'Product-Code', 1, 0, 'C');
$pdf->Cell(35, 10, 'Category', 1, 0, 'C');
$pdf->Cell(40, 10, 'Sale-Amount', 1, 1, 'C');



// Prepare and execute SQL query
$sql = "SELECT * FROM daily_sales WHERE date BETWEEN ? AND ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $s_Date, $e_Date);
$stmt->execute();
$result = $stmt->get_result();

// Format data into HTML table
if ($result->num_rows > 0) {
   
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(35, 10, $row["date"], 1, 0, 'C');
        $pdf->Cell(35, 10, $row["product_name"], 1, 0, 'C');
        $pdf->Cell(35, 10, $row["product_code"], 1, 0, 'C');
        $pdf->Cell(35, 10, $row["category"], 1, 0, 'C');
        $pdf->Cell(40, 10, 'Rs'.$row["amount"].'/=', 1, 1, 'C');
    }
 

} else {
    $pdf->Cell(0, 10, 'No sales data found', 1, 1, 'C'); echo "<p>No sales data found for the selected date range.</p>";
}


// Output PDF
 // Current date or you can set it as per your requirement
$pdf->Output('sales_Report_' . $date . '.pdf', 'D');
?>
