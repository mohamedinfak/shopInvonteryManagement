<?php
if(isset($_POST["btn_print"])){
    header('location:fpdf_generate.php');

}




?>