<?php
// Include the database connection file
include('conn.php');

// Start the session
session_start();



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    // Hash the password
    

    // Prepare the SQL insert statement
    $sql = "INSERT INTO admins (username, email, password) VALUES (?, ?, ?)";
    
    // Initialize the statement
    $stmt = $conn->prepare($sql);
    
    // Bind the parameters to the statement
    $stmt->bind_param("sss", $username, $email, $password);

    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['message'] = "Admin registered successfully.";
    } else {
        $_SESSION['message'] = "Error registering admin.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}

// Redirect back to the registration page
header("Location:register.php");
exit();
?>
