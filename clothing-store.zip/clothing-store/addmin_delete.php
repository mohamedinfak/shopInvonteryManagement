<?php
// Include the database connection file
include('conn.php');

// Start the session
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare the SQL delete statement
    $sql = "DELETE FROM admins WHERE id = ?";
    
    // Initialize the statement
    $stmt = $conn->prepare($sql);
    
    // Bind the parameter to the statement
    $stmt->bind_param("i", $id);

    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['message'] = "Admin deleted successfully.";
    } else {
        $_SESSION['message'] = "Error deleting admin.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}

// Redirect back to the admin list page
header("Location:register_admin.php");
exit();
?>
