
<?php
// Include the database connection file
include('conn.php');
session_start();
if ($_SESSION['admin_username']== "") {
    header('location:login.php');
}

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Sales</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
           margin-left:20%;
           margin-top:40px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="date"],
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .message {
            color: green;
            margin-bottom: 15px;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }
        .print-btn{
            margin-top:100px;
            background-color: Tomato;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100px;

        }
        .print-btn:hover{
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    

<?php @include 'nv.php'; ?>
    <div class="container">
        <h2>Daily Sales</h2>
        <!-- Sales Entry Form -->
        <form action="add_sales.php" method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" required>
            </div>
            <div class="form-group">
                <label for="product_code">Product Code:</label>
                <input type="text" id="product_code" name="product_code" required>
            </div>
            <div class="form-group">
                <label for="category">Category:</label>
                <select id="category" name="category" required>
                    <option value="">Select Category</option>
                    <option value="Men">Men</option>
                    <option value="Women">Women</option>
                    <option value="Kids">Kids</option>
                </select>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="number" id="amount" name="amount" required>
            </div>
            <button type="submit" name="submit">Submit</button>
        </form>
        <!-- PHP Code for Handling Form Submission and Displaying Sales Table -->
      
    </div>


    
    <div class="container"><?php
        include('conn.php'); // Include your database connection file

        // Process form submission
        
        // Delete data
        if(isset($_POST['delete'])) {
            $id = $_POST['id'];

            // Delete data from the database
            $delete_sql = "DELETE FROM daily_sales WHERE id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $id);

            if ($delete_stmt->execute()) {
                echo "<div class='message'>Sales added successfully!</div>";
            } else {
                echo "<div class='error'>Error: " . $delete_stmt->error . "</div>";
            }

            $delete_stmt->close();

        }
        // Display sales table
        $sql = "SELECT * FROM daily_sales";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Product Name</th>
                            <th>Product Code</th>
                            <th>Category</th>
                            <th>Amount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['date']}</td>
                        <td>{$row['product_name']}</td>
                        <td>{$row['product_code']}</td>
                        <td>{$row['category']}</td>
                        <td>{$row['amount']}</td>
                        <td>
                            <form action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "' method='post'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <button type='submit' name='delete'>Delete</button>
                            </form>
                        </td>
                    </tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p>No sales found.</p>";
        }
        ?><form action="printprocess.php" method="post">
            <button name="btn_print" class="print-btn">Print</button>
        </form>
          
        </div>
    <script>
        function validateForm() {
            var date = document.getElementById('date').value;
            var product_name = document.getElementById('product_name').value;
            var product_code = document.getElementById('product_code').value;
            var category = document.getElementById('category').value;
            var amount = document.getElementById('amount').value;

            if (date === '' || product_name === '' || product_code === '' || category === '' || amount === '') {
                alert('All fields are required.');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
<script>setTimeout(function() {
    location.reload();
}, 10000); // Adjust the delay as needed</script>

<script>