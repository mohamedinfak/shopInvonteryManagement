<?php
include('conn.php');
session_start();
if ($_SESSION['admin_username'] == "") {
    header('location:login.php');
    exit(); // Ensure the script stops executing after redirection
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["btn-show"])) {
    if (isset($_POST['startDate']) && isset($_POST['endDate'])) {
        $startDate = $_POST['startDate'];
        $endDate = $_POST['endDate'];

        $_SESSION['start_date'] = $startDate;
        $_SESSION['end_date'] = $endDate;

        // Prepare and execute SQL query
        $sql = "SELECT * FROM daily_sales WHERE date BETWEEN ? AND ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Data</title>
    <style>
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .print-btn {
            margin-top: 100px;
            background-color: Tomato;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100px;
        }

        .print-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php @include 'nv.php'; ?>
<div class="container">
    <h2>Select Date Range</h2>
    <form id="dateForm" method="post">
        <label for="startDate">Start Date:</label>
        <input type="date" id="startDate" name="startDate" required>

        <label for="endDate">End Date:</label>
        <input type="date" id="endDate" name="endDate" required>

        <button type="submit" name="btn-show" id="submitBtn">Submit</button>
    </form>

    <?php
    // Display sales data if available
    if (isset($result)) {
        if ($result->num_rows > 0) {
            echo "<table>
                    <thead>
                        <tr>
                            <th>Sale ID</th>
                            <th>Amount</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['amount']}</td>
                        <td>{$row['date']}</td>
                    </tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p>No sales data found for the selected date range.</p>";
        }
    }
    ?>
    <a href="salesReport_pdf.php"><button name="btn_print" class="print-btn">Print</button></a>
</div>
</body>
</html>
