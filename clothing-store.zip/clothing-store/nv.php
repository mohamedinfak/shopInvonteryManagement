<html>

<head>
    <title>Addmin_Navigation_Panel</title>
    <style>
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color:black;
            padding-top: 30px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 15px;
        }

        .sidebar ul li a {
            color: #ffffff;
            text-decoration: none;
            display: block;
        }

        .sidebar ul li a:hover {
            background-color: green;
        
            padding: 5px;
         
        }
    </style>
</head>

<body>

    <section>
        <div class="sidebar">
            <ul>
                <li><a href="dcbord.php" target="_self">Dashboard</a></li>
                
                <li><a href="add_product.php" target="_self">Add_product</a></li>
                <li><a href="sales_daily.php" target="_self">Daily_Sales</a></li>
                <li><a href="register.php" target="_self">Users</a></li>
                <li><a href="suplire_add.php">suplire_add</a></li>
                <li><a href="sales_report.php">Sales_Reports</a></li>
                
                <li><a href="logout.php">logout</a></li>
                <!-- Add more navigation links as needed -->
            </ul>
        </div>
    </section>
</body>

</html>