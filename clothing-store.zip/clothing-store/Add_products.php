<?php
include ('conn.php');
session_start();
if ($_SESSION['admin_username']== "") {
    header('location:login.php');
}


$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Packages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            margin: 20px 20%;
            width: 80%;
            max-width: 1000px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-top: 5px;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: block;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .container-2 {
        margin-left: 300px;
            width: 90%;
            mar
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 4px;
            overflow: hidden;
        }

        .card-header {
            text-align: center;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
        }

        .card-body {
            padding: 20px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            font-weight: bold;
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
    <script>
        window.onload = function () {
            var message = "<?php echo $message; ?>";
            if (message) {
                alert(message);
            }
        }
    </script>
</head>

<body>

    <?php @include 'nv.php'; ?>

    <div class="container">
        <h2 style="text-align: center;">Add Product</h2>
        <form action="add_products_Action.php" method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" required>
            </div>

            <div class="form-group">
                <label for="product_type">Product Type:</label>
                <input type="text" id="product_type" name="product_type" required>
            </div>

            <div class="form-group">
                <label for="product_price">Price:</label>
                <input type="number" id="product_price" name="product_price" min="0" step="0.01" required>
            </div>

            <div class="form-group">
                <label for="product_quantity">Quantity:</label>
                <input type="number" id="product_quantity" name="product_quantity" min="0" required>
            </div>

            <div class="form-group">
                <label for="brand_name">Brand Name:</label>
                <input type="text" id="brand_name" name="brand_name">
            </div>

            <div class="form-group">
                <label for="generic_name">Generic Name:</label>
                <input type="text" id="generic_name" name="generic_name">
            </div>

            <div class="form-group">
                <label for="category_description">Category / Description:</label>
                <input type="text" id="category_description" name="category_description">
            </div>

            <div class="form-group">
                <label for="date_arrival">Date Arrival:</label>
                <input type="date" id="date_arrival" name="date_arrival">
            </div>

            <div class="form-group">
                <label for="selling_price">Selling Price:</label>
                <input type="number" id="selling_price" name="selling_price" min="0" step="0.01">
            </div>

            <div class="form-group">
                <label for="original_price">Original Price:</label>
                <input type="number" id="original_price" name="original_price" min="0" step="0.01">
            </div>

            <div class="form-group">
                <label for="profit">Profit:</label>
                <input type="number" id="profit" name="profit" min="0" step="0.01">
            </div>

            <div class="form-group">
                <label for="supplier">Supplier:</label>
                <select id="supplier" name="supplier">
                    <option value="supplier1">Supplier 1</option>
                    <option value="supplier2">Supplier 2</option>
                    <option value="supplier3">Supplier 3</option>
                </select>
            </div>

            <button type="submit">Add Product</button>
        </form>
    </div>

   

</body>
</html>
