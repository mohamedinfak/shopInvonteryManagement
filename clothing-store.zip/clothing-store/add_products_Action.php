

<?php
// Include database connection file
@include 'conn.php';
session_start();


// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $product_name = $_POST['product_name'];
    $product_type = $_POST['product_type'];
    $product_price = $_POST['product_price'];
    $product_quantity = $_POST['product_quantity'];
    $brand_name = $_POST['brand_name'];
    $generic_name = $_POST['generic_name'];
    $category_description = $_POST['category_description'];
    $date_arrival = $_POST['date_arrival'];
    $selling_price = $_POST['selling_price'];
    $original_price = $_POST['original_price'];
    $profit = $selling_price - $original_price;
    $supplier = $_POST['supplier'];

    // Prepare an insert statement
    $sql = "INSERT INTO products (product_name, product_type, product_price, product_quantity, brand_name, generic_name, category_description, date_arrival, selling_price, original_price, profit, supplier) VALUES ('$product_name', '$product_type', '$product_price', '$product_quantity', '$brand_name',' $generic_name', '$category_description', '$date_arrival',' $selling_price',' $original_price', '$profit', '$supplier')";
    $stmt = mysqli_query($conn,$sql );
    if ($stmt) {
            echo "Product added successfully.";
        } else {
            echo "Error: Could not execute the query: " . mysqli_error($conn);
        }

        // Close statement
      
   

    // Close connection
    mysqli_close($conn);
}



// Close connection

?>
</body>
</html>
