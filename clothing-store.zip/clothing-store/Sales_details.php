<?php
include ('conn.php');
session_start();

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock_Details</title>
    <style>
    
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 8px; /* Reduced padding */
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-top: 5px;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: block;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .container-2 {
            margin-left: 20%; /* Reduced margin-left */
            max-width: 80%; /* Reduced max-width */

            margin-top: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .container{
            margin-left: 20%; /* Reduced margin-left */
            max-width: 80%; /* Reduced max-width */
            display:flex;
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        .card {
            border: 1px solid #ccc;
            border-radius: 4px;
            overflow: hidden;
        }

        .card-header {
            text-align: center;
            padding: 8px; /* Reduced padding */
            background-color: #3498db;
            color: #fff;
        }

        .card-body {
            padding: 10px; /* Reduced padding */
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px; /* Reduced padding */
            border: 1px solid #ddd;
            text-align: left;
            font-size: 12px; /* Reduced font size */
        }

        th {
            font-weight: bold;
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>

    </style>
   
</head>
<script>setTimeout(function() {
    location.reload();
}, 10000); // Adjust the delay as needed</script>

<script>

<body>

    <?php @include 'nv.php'; ?>
   




    <div class="container-2">
        <div class="card">
            <div class="card-header">
                Available Stocks
            </div>
            <div class="card-body">
                <?php
                $sql = "SELECT * FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo "<table>
                            <thead>
                                <tr>
                                    <th> ID</th>
                                    <th>product_name</th>
                                    <th>product_type</th>
                                    <th>product_price</th>
                                    <th>product_quantit</th>
                                    <th>generic_name</th>
                                     <th>category_description</th>
                                    <th>date_arrival</th>
                                    <th>selling_price</th>
                                    <th>original_price</th>
                                    <th>profit</th>
                                     <th>supplier</th>
                                </tr>
                            </thead>
                            <tbody>";
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['product_name']}</td>
                                <td>{$row['product_type']}</td>
                                <td>{$row['product_price']}</td>
                                <td>{$row['product_quantity']}</td>
                                <td>{$row['generic_name']}</td>
                                <td>{$row['category_description']}</td>
                                <td>{$row['date_arrival']}</td>
                                <td>{$row['selling_price']}</td>
                                <td>{$row['original_price']}</td>
                                <td>{$row['profit']}</td>
                                  <td>{$row['supplier']}</td>
                                   
                            </tr>";
                    }
                    echo "</tbody></table>";
                } else {
                    echo "No sales.";
                }
                ?>
            </div>
        </div>
    </div>

</body>
</html>
