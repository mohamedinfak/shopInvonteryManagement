<?php
// Include the database connection file
include('conn.php');
session_start();
if ($_SESSION['admin_username']== "") {
    header('location:login.php');
}


// Fetch counts from each table
$tables = array("admins", "daily_sales", "products","suppliers"); // List of your tables
$table_counts = array();

foreach ($tables as $table) {
    $sql = "SELECT COUNT(*) AS count FROM $table";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $table_counts[$table] = $row['count'];
    } else {
        $table_counts[$table] = 0;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
    </style>
</head>
<body>
<?php @include 'nv.php'; ?>
    <div class="container">
        <h2>Dashboard</h2>
        <table>
            <thead>
                <tr>
                    <th>Table Name</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($table_counts as $table => $count): ?>
                    <tr>
                        <td><?php echo $table; ?></td>
                        <td><?php echo $count; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
