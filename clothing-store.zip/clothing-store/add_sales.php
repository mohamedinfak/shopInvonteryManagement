<?php

include('conn.php');

if (isset($_POST['submit'])) {
    $date = $_POST['date'];
    $product_name = $_POST['product_name'];
    $product_code = $_POST['product_code'];
    $category = $_POST['category'];
    $amount = $_POST['amount'];

    // Insert sales into the database
    $sql = "INSERT INTO daily_sales (date, product_name, product_code, category, amount) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssd", $date, $product_name, $product_code, $category, $amount);

    if ($stmt->execute()) {
       header("Location: sales_daily.php");
    } else {
        echo "<div class='error'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();
}

?>