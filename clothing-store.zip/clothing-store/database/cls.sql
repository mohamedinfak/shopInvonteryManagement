-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2024 at 06:22 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cls`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(7, 'admin', 'thivatharan738@gmail.com', '25d55ad283aa400af464c76d713c07ad', '2024-06-09 00:17:36'),
(8, 'infak', 'infakstc@gmail.com', '25d55ad283aa400af464c76d713c07ad', '2024-06-12 18:01:31');

-- --------------------------------------------------------

--
-- Table structure for table `daily_sales`
--

CREATE TABLE `daily_sales` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_sales`
--

INSERT INTO `daily_sales` (`id`, `date`, `product_name`, `product_code`, `category`, `amount`) VALUES
(8, '2024-06-12', 'tshirt', '123', 'Men', 1223.00),
(9, '2024-06-14', 'tshirt', '1234', 'Men', 12233.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `item_code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `size` varchar(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `email`, `phone`, `address`, `created_at`) VALUES
(12, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:44'),
(13, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:44'),
(14, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:44'),
(15, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:44'),
(16, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:44'),
(17, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:44'),
(18, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:45'),
(19, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:45'),
(20, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:45'),
(21, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:45'),
(22, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:45'),
(23, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:46'),
(24, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:46'),
(25, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:46'),
(26, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:46'),
(27, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:46'),
(28, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:46'),
(29, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:47'),
(30, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:47'),
(31, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:47'),
(32, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:47'),
(33, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:47'),
(34, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:47'),
(35, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:48'),
(36, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:48'),
(37, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:48'),
(38, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:48'),
(39, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:49'),
(40, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:49'),
(41, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:49'),
(42, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:49'),
(43, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:49'),
(44, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:50'),
(45, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:50'),
(46, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:51'),
(47, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:52'),
(48, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:53'),
(49, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:54'),
(50, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:55'),
(51, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:56'),
(52, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:57'),
(53, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:58'),
(54, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:26:59'),
(55, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:00'),
(56, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:01'),
(57, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:01'),
(58, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:01'),
(59, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:02'),
(60, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:02'),
(61, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:02'),
(62, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:03'),
(63, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:04'),
(65, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:27:08'),
(66, 'ABC Apparel', 'thivatharan738@gmail.com', '0750626622', 'CBD St., EFG City', '2024-07-08 06:28:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daily_sales`
--
ALTER TABLE `daily_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `daily_sales`
--
ALTER TABLE `daily_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
